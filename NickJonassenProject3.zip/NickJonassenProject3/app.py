import numpy as np
from flask import Flask, request, render_template
import pickle
import pandas as pd

flask_app = Flask(__name__)
CLFmodel = pickle.load(open('model.pkl', 'rb'))  # Load the trained model

expected_columns = [
    'Rank', 'Year', 'NA_Sales', 'EU_Sales', 'JP_Sales',
    'Platform_3DO', 'Platform_3DS', 'Platform_DC', 'Platform_DS',
    'Platform_GB', 'Platform_GBA', 'Platform_GC', 'Platform_GEN',
    'Platform_GG', 'Platform_N64', 'Platform_NES', 'Platform_NG',
    'Platform_PC', 'Platform_PCFX', 'Platform_PS', 'Platform_PS2',
    'Platform_PS3', 'Platform_PS4', 'Platform_PSP', 'Platform_PSV',
    'Platform_SAT', 'Platform_SCD', 'Platform_SNES', 'Platform_TG16',
    'Platform_WS', 'Platform_Wii', 'Platform_WiiU', 'Platform_X360',
    'Platform_XB', 'Platform_XOne', 'Genre_Adventure', 'Genre_Fighting',
    'Genre_Misc', 'Genre_Platform', 'Genre_Puzzle', 'Genre_Racing', 
    'Genre_Role-Playing', 'Genre_Shooter', 'Genre_Simulation',
    'Genre_Sports', 'Genre_Strategy'
]

@flask_app.route("/")   
def index():
    return render_template("index.html")

@flask_app.route("/predict", methods=["POST"])   
def predict():
    try:
        Rank = int(request.form['Rank'])
        Year = int(request.form['Year'])
        NA_Sales = float(request.form['NA_Sales'])
        EU_Sales = float(request.form['EU_Sales'])
        JP_Sales = float(request.form['JP_Sales'])
        
        platform = request.form['Platform']
        genre = request.form['Genre']
        
        features = {
            'Rank': Rank,
            'Year': Year,
            'NA_Sales': NA_Sales,
            'EU_Sales': EU_Sales,
            'JP_Sales': JP_Sales,
            'Platform_3DO': 1 if platform == '3DO' else 0,
            'Platform_3DS': 1 if platform == '3DS' else 0,
            'Platform_DC': 1 if platform == 'DC' else 0,
            'Platform_DS': 1 if platform == 'DS' else 0,
            'Platform_GB': 1 if platform == 'GB' else 0,
            'Platform_GBA': 1 if platform == 'GBA' else 0,
            'Platform_GC': 1 if platform == 'GC' else 0,
            'Platform_GEN': 1 if platform == 'GEN' else 0,
            'Platform_GG': 1 if platform == 'GG' else 0,
            'Platform_N64': 1 if platform == 'N64' else 0,
            'Platform_NES': 1 if platform == 'NES' else 0,
            'Platform_NG': 1 if platform == 'NG' else 0,
            'Platform_PC': 1 if platform == 'PC' else 0,
            'Platform_PCFX': 1 if platform == 'PCFX' else 0,
            'Platform_PS': 1 if platform == 'PS' else 0,
            'Platform_PS2': 1 if platform == 'PS2' else 0,
            'Platform_PS3': 1 if platform == 'PS3' else 0,
            'Platform_PS4': 1 if platform == 'PS4' else 0,
            'Platform_PSP': 1 if platform == 'PSP' else 0,
            'Platform_PSV': 1 if platform == 'PSV' else 0,
            'Platform_SAT': 1 if platform == 'SAT' else 0,
            'Platform_SCD': 1 if platform == 'SCD' else 0,
            'Platform_SNES': 1 if platform == 'SNES' else 0,
            'Platform_TG16': 1 if platform == 'TG16' else 0,
            'Platform_WS': 1 if platform == 'WS' else 0,
            'Platform_Wii': 1 if platform == 'Wii' else 0,
            'Platform_WiiU': 1 if platform == 'WiiU' else 0,
            'Platform_X360': 1 if platform == 'X360' else 0,
            'Platform_XB': 1 if platform == 'XB' else 0,
            'Platform_XOne': 1 if platform == 'XOne' else 0,
            'Genre_Adventure': 1 if genre == 'Adventure' else 0,
            'Genre_Fighting': 1 if genre == 'Fighting' else 0,
            'Genre_Misc': 1 if genre == 'Misc' else 0,
            'Genre_Platform': 1 if genre == 'Platform' else 0,
            'Genre_Puzzle': 1 if genre == 'Puzzle' else 0,
            'Genre_Racing': 1 if genre == 'Racing' else 0,
            'Genre_Role-Playing': 1 if genre == 'Role-Playing' else 0,
            'Genre_Shooter': 1 if genre == 'Shooter' else 0,
            'Genre_Simulation': 1 if genre == 'Simulation' else 0,
            'Genre_Sports': 1 if genre == 'Sports' else 0,
            'Genre_Strategy': 1 if genre == 'Strategy' else 0
        }

        feature_df = pd.DataFrame([features])

        feature_df = feature_df.reindex(columns=expected_columns, fill_value=0)

        prediction = CLFmodel.predict(feature_df)
        predicted_sales = prediction[0]

        return render_template("index.html", predicted_text=f"Predicted Other Sales: {predicted_sales:.2f} million")

    except Exception as e:
        print("Error:", str(e))
        return render_template("index.html", predicted_text=f"Error: {str(e)}")

if __name__ == "__main__":
    flask_app.run(debug=True)
